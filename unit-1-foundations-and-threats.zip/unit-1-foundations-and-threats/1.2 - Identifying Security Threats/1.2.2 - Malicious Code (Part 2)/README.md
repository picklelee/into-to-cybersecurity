# 1.2.1 - Malicious Code Part 2

## Lesson Objective(s):
- Identify the types of malicious software that exist and how they can be layered to increase the
security threat.
- Examine how malware has a negative impact on a computer system and also on a person.

## Guiding Question(s):
- How does malicious software impact computer systems?

### Lecture Notes
> From the course notes reviewed in class, take note on the material from this lesson as it relates to the Lesson Objectives and Guiding Question(s):

...

### Application / Personal Research / Summary
> In your own words, write a summary of this lesson and connect it to yourself and the real-world. If needbe, do a rapid research on the topic to help with you summary

...

### Vocabulary
> Include the vocabulary word(s) from this lesson with a defintion

...
