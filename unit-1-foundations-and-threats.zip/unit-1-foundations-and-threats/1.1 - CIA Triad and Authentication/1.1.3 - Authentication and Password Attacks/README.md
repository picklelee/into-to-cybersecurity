# 1.1.3 – Authentication and Password Attacks

## Lesson Objective(s):
- Define database as a collection of data organized for efficient organization and retrieval.
- Explain 3 password guessing attack methods that use database information.

## Guiding Question(s):
- How can databases be used in password guessing attacks?

### Lecture Notes
> From the course notes reviewed in class, take note on the material from this lesson as it relates to the Lesson Objectives and Guiding Question(s):

...

### Application / Personal Research / Summary
> In your own words, write a summary of this lesson and connect it to yourself and the real-world. If needbe, do a rapid research on the topic to help with you summary

...

### Vocabulary
> Include the vocabulary word(s) from this lesson with a defintion

...
