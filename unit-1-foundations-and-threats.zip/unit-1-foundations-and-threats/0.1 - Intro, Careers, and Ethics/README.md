# 0.1 - Intro, Careers, and Ethics

## Lesson Objective(s):
- Understand the importance of cybersecurity professionals
- Understand the benefits of being a cybersecurity professional
- Know the objectives of this course
- Create a code of conduct for the course and understand why a code of conduct is important for this course

## Guiding Question(s):
- What careers are available to students and what are the benefits of these careers?
- Why is a code of behavior important for this course?

### Lecture Notes
> From the course notes reviewed in class, take note on the material from this lesson as it relates to the Lesson Objectives and Guiding Question(s):

...

### Application / Personal Research / Summary
> In your own words, write a summary of this lesson and connect it to yourself and the real-world. If needbe, do a rapid research on the topic to help with you summary

...

### Vocabulary
> Include the vocabulary word(s) from this lesson with a defintion

...
